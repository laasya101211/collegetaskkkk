from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Hackathon Team Formation and Ranking', description='Validate team sizes, total round scores, and rank teams using defined tie-break rules.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    minimum=int(data.get("min_team_size",2)); maximum=int(data.get("max_team_size",5)); teams=[]; invalid=[]
    for t in data.get("teams",[]):
        members=t.get("members",[]); valid=minimum<=len(members)<=maximum
        row={"team":t["name"],"members":members,"team_size":len(members),"valid_team_size":valid,
             "round_scores":[float(x) for x in t.get("round_scores",[])],"total_score":sum(float(x) for x in t.get("round_scores",[]))}
        teams.append(row)
        if not valid: invalid.append(t["name"])
    ranked=sorted([t for t in teams if t["valid_team_size"]],key=lambda x:(-x["total_score"],-max(x["round_scores"],default=0),x["team"]))
    for i,t in enumerate(ranked,1): t["rank"]=i
    return {"teams":teams,"invalid_teams":invalid,"rankings":ranked}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Hackathon Team Formation and Ranking'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
