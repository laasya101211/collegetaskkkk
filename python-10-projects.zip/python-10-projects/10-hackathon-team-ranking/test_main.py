import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'min_team_size': 2, 'max_team_size': 5, 'teams': [{'name': 'Code Ninjas', 'members': ['A', 'B', 'C'], 'round_scores': [80, 90, 85]}, {'name': 'Byte Squad', 'members': ['D', 'E'], 'round_scores': [90, 90, 80]}, {'name': 'Solo', 'members': ['F'], 'round_scores': [100, 100]}]}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
