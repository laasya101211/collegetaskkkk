import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'grace_marks': 5, 'subjects': [{'name': 'Math', 'mark': 38, 'maximum': 100, 'pass_mark': 40}, {'name': 'English', 'mark': 75, 'maximum': 100, 'pass_mark': 40}]}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
