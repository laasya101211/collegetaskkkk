# Examination Result and Grace-Mark Validation

Apply subject-wise pass marks and a grace-mark policy without exceeding maximum marks.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Open http://127.0.0.1:8000. API documentation is at http://127.0.0.1:8000/docs.

## API

- `GET /health` — health check
- `POST /api/calculate` — submit JSON input and receive calculated results

## Deploy to Vercel

Import this folder as a separate Vercel project (set its Root Directory to `02-examination-result-validation` if importing the parent repository). Vercel will use `vercel.json` and `api/index.py`.

## Tests

Run `python -m unittest -v`.
