from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Examination Result and Grace-Mark Validation', description='Apply subject-wise pass marks and a grace-mark policy without exceeding maximum marks.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    results=[]; total=0; passed=True
    grace=int(data.get("grace_marks",0)); grace_used=False
    for s in data.get("subjects",[]):
        name=str(s["name"]); mark=float(s["mark"]); maximum=float(s["maximum"]); minimum=float(s["pass_mark"])
        if maximum <= 0 or not 0 <= mark <= maximum: raise ValueError(f"Invalid marks for {name}")
        final=mark
        if mark < minimum and not grace_used and grace > 0 and minimum-mark <= grace:
            final=min(maximum, mark+grace); grace_used=True
        ok=final >= minimum
        passed = passed and ok; total += final
        results.append({"subject":name,"original_mark":mark,"final_mark":final,"passed":ok,"grace_applied":final>mark})
    maximum_total=sum(float(s["maximum"]) for s in data.get("subjects",[]))
    pct=round(total/maximum_total*100,2) if maximum_total else 0
    return {"subjects":results,"total":round(total,2),"maximum_total":maximum_total,"percentage":pct,
            "classification":"PASS" if passed and results else "FAIL","grace_used":grace_used}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Examination Result and Grace-Mark Validation'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
