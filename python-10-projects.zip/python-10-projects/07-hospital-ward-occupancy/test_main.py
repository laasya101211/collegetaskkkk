import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'wards': [{'name': 'General', 'capacity': 30, 'daily_occupancy': {'Monday': 25, 'Tuesday': 32}}, {'name': 'ICU', 'capacity': 10, 'daily_occupancy': {'Monday': 8, 'Tuesday': 9}}]}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
