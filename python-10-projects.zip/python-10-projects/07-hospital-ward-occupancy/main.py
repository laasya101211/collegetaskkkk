from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Hospital Ward Occupancy Monitoring', description='Analyse ward occupancy by day, calculate utilization, detect capacity violations, and find peak demand.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    wards=data.get("wards",[]); rows=[]; peak=None; violations=[]
    for ward in wards:
        capacity=int(ward["capacity"])
        if capacity<=0: raise ValueError("Ward capacity must be positive")
        for day,count in ward.get("daily_occupancy",{}).items():
            count=int(count); utilization=count/capacity*100
            row={"ward":ward["name"],"day":day,"occupied":count,"capacity":capacity,"utilization_percent":round(utilization,2)}
            rows.append(row)
            if count>capacity: violations.append(row)
            if peak is None or count>peak["occupied"]: peak=row
    return {"daily_records":rows,"capacity_violations":violations,"peak_demand":peak,
            "average_utilization_percent":round(sum(r["utilization_percent"] for r in rows)/len(rows),2) if rows else 0}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Hospital Ward Occupancy Monitoring'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
