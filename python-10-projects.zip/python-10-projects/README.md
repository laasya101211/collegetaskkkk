# Python Portfolio: 10 Interactive Problem-Solving Projects

Ten independent Python + FastAPI web applications. Each project has its own backend, browser interface, sample JSON input, API documentation, README, Vercel configuration, and automated test.

## Projects
1. **Campus Event Financial Planning** — Calculate event costs, participant contributions, sponsorship shortfalls, and break-even registrations.
2. **Examination Result and Grace-Mark Validation** — Apply subject-wise pass marks and a grace-mark policy without exceeding maximum marks.
3. **Multi-Currency Travel Budget Analysis** — Convert expenses using exchange rates and fees, compare with budget, and find the largest category.
4. **Attendance Recovery Computation** — Calculate attendance and the minimum consecutive classes needed to reach an eligibility threshold.
5. **Student Performance Trend Analysis** — Compare exam scores, identify improvements, declines, weak subjects, and classifications.
6. **Multi-Product Shopping Budget Constraint** — Apply discount conditions and suggest quantity reductions to fit a shopping budget.
7. **Hospital Ward Occupancy Monitoring** — Analyse ward occupancy by day, calculate utilization, detect capacity violations, and find peak demand.
8. **Sports Tournament Ranking System** — Calculate league points and tie-break values from match results and rank teams.
9. **Bus Passenger Occupancy Simulation** — Track passengers boarding and alighting at each stop and flag capacity violations.
10. **Hackathon Team Formation and Ranking** — Validate team sizes, total round scores, and rank teams using defined tie-break rules.

## Run one project locally
Open a project folder, then:

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Visit http://127.0.0.1:8000. Edit the sample JSON and click **Calculate results**. The interactive API documentation is at `/docs`.

## Tests
From an individual project folder:

```bash
python -m unittest -v
```

## GitHub
Create a repository, extract/copy this portfolio into it, then:

```bash
git init
git add .
git commit -m "Add 10 Python problem-solving web projects"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## Vercel deployment
Each subfolder is designed to be deployed as its own Vercel project. In Vercel, import the same GitHub repository ten times and set a different **Root Directory** for each deployment (for example `01-campus-event-financial-planning`). The project uses the included `vercel.json`.

## Important
These projects use example data. Replace it with your own values when demonstrating them. The browser interface calls the Python API; calculations are performed by Python, not JavaScript.
