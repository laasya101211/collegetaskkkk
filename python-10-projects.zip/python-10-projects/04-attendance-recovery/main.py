from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Attendance Recovery Computation', description='Calculate attendance and the minimum consecutive classes needed to reach an eligibility threshold.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    attended=int(data["attended"]); conducted=int(data["conducted"]); threshold=float(data.get("threshold",75))
    if conducted < 0 or attended < 0 or attended > conducted or not 0 < threshold <= 100: raise ValueError("Check attendance values and threshold")
    current=attended/conducted*100 if conducted else 0
    scenarios=[]
    for future in data.get("scenarios",[{"name":"Attend every class","attendance_rate":100}]):
        rate=float(future.get("attendance_rate",100))/100
        if not 0 <= rate <= 1: raise ValueError("Scenario attendance rate must be 0–100")
        n=0
        while n < 100000 and (attended+rate*n)/(conducted+n)*100 < threshold: n+=1
        scenarios.append({"name":future.get("name","Scenario"),"attendance_rate":rate*100,"classes_needed":n if n<100000 else None,
                          "projected_percentage":round((attended+rate*n)/(conducted+n)*100,2) if n<100000 and conducted+n else 0})
    return {"current_percentage":round(current,2),"eligible_now":current>=threshold,"threshold":threshold,"scenarios":scenarios}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Attendance Recovery Computation'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
