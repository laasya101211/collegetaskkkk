import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'attended': 60, 'conducted': 80, 'threshold': 75, 'scenarios': [{'name': 'Attend all classes', 'attendance_rate': 100}, {'name': 'Attend 90%', 'attendance_rate': 90}]}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
