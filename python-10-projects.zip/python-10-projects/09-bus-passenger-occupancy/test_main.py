import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'capacity': 40, 'initial_passengers': 20, 'stops': [{'name': 'Stop 1', 'alighting': 5, 'boarding': 10}, {'name': 'Stop 2', 'alighting': 8, 'boarding': 25}]}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
