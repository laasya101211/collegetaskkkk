from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Bus Passenger Occupancy Simulation', description='Track passengers boarding and alighting at each stop and flag capacity violations.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    capacity=int(data["capacity"]); passengers=int(data.get("initial_passengers",0)); stops=[]; violations=[]
    if capacity<=0 or not 0<=passengers<=capacity: raise ValueError("Invalid capacity or initial passenger count")
    for stop in data.get("stops",[]):
        alight=int(stop.get("alighting",0)); board=int(stop.get("boarding",0))
        if alight<0 or board<0 or alight>passengers: raise ValueError(f"Invalid counts at {stop['name']}")
        passengers=passengers-alight+board
        row={"stop":stop["name"],"alighted":alight,"boarded":board,"passengers":passengers,"capacity":capacity,"over_capacity":passengers>capacity}
        stops.append(row)
        if row["over_capacity"]: violations.append(row)
    return {"stops":stops,"final_passengers":passengers,"capacity":capacity,"capacity_violations":violations}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Bus Passenger Occupancy Simulation'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
