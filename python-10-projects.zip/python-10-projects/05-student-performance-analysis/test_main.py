import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'subjects': ['Math', 'English', 'Science'], 'exams': [{'Math': 55, 'English': 60, 'Science': 45}, {'Math': 65, 'English': 58, 'Science': 50}, {'Math': 72, 'English': 63, 'Science': 55}], 'weak_below': 50}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
