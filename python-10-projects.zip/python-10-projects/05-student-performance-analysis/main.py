from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Student Performance Trend Analysis', description='Compare exam scores, identify improvements, declines, weak subjects, and classifications.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    subjects=data.get("subjects",[]); exams=data.get("exams",[])
    if len(exams)<2: raise ValueError("Provide at least two examinations")
    summary=[]; deltas=[]
    for subject in subjects:
        scores=[float(exam.get(subject,0)) for exam in exams]
        delta=scores[-1]-scores[0]; deltas.append(delta)
        summary.append({"subject":subject,"scores":scores,"change":round(delta,2),"trend":"Improved" if delta>0 else "Declined" if delta<0 else "Unchanged"})
    averages=[sum(float(e.get(s,0)) for s in subjects)/len(subjects) if subjects else 0 for e in exams]
    overall=sum(averages)/len(averages) if averages else 0
    weak=[r["subject"] for r in summary if r["scores"][-1] < float(data.get("weak_below",40))]
    return {"subjects":summary,"exam_averages":[round(x,2) for x in averages],"overall_average":round(overall,2),
            "weak_subjects":weak,"classification":"Excellent" if overall>=85 else "Good" if overall>=70 else "Satisfactory" if overall>=50 else "Needs Improvement"}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Student Performance Trend Analysis'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
