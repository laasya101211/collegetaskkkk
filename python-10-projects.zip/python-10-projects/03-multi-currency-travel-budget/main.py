from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Multi-Currency Travel Budget Analysis', description='Convert expenses using exchange rates and fees, compare with budget, and find the largest category.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    rate=float(data.get("exchange_rate",1)); fee_pct=float(data.get("conversion_fee_percent",0)); budget=float(data.get("budget",0))
    if rate <= 0 or fee_pct < 0: raise ValueError("Exchange rate must be positive and fee cannot be negative")
    rows=[]; total=0
    for e in data.get("expenses",[]):
        amount=float(e["amount"]); converted=amount*rate; fee=converted*fee_pct/100; final=converted+fee
        rows.append({"category":e["category"],"source_amount":amount,"converted":round(converted,2),"fee":round(fee,2),"total":round(final,2)})
        total += final
    largest=max(rows,key=lambda x:x["total"])["category"] if rows else None
    return {"expenses":rows,"total_home_currency":round(total,2),"budget":budget,"remaining":round(budget-total,2),
            "within_budget":total<=budget,"largest_expense_category":largest}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Multi-Currency Travel Budget Analysis'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
