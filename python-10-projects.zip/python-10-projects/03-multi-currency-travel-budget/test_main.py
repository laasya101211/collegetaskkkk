import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'exchange_rate': 83.5, 'conversion_fee_percent': 2, 'budget': 50000, 'expenses': [{'category': 'Hotel', 'amount': 200}, {'category': 'Food', 'amount': 100}, {'category': 'Transport', 'amount': 80}]}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
