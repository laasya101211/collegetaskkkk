import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'budget': 1000, 'products': [{'name': 'Notebook', 'price': 100, 'quantity': 4}, {'name': 'Bag', 'price': 500, 'quantity': 2, 'discount_min_quantity': 2, 'discount_percent': 10}]}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
