from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Multi-Product Shopping Budget Constraint', description='Apply discount conditions and suggest quantity reductions to fit a shopping budget.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    budget=float(data["budget"]); items=[]; total=0
    for p in data.get("products",[]):
        price=float(p["price"]); qty=int(p["quantity"]); minimum=int(p.get("discount_min_quantity",0)); discount=float(p.get("discount_percent",0))
        if price<0 or qty<0 or not 0<=discount<=100: raise ValueError("Invalid product price, quantity, or discount")
        applied=discount if minimum and qty>=minimum else 0
        line=price*qty*(1-applied/100); total+=line
        items.append({"product":p["name"],"quantity":qty,"unit_price":price,"discount_percent":applied,"line_total":round(line,2)})
    reductions=[]; remaining=total
    # Reduce one unit at a time from highest effective unit price until within budget.
    candidates=[]
    for p in data.get("products",[]):
        q=int(p["quantity"]); price=float(p["price"]); d=float(p.get("discount_percent",0))
        candidates.append([p["name"],q,price*(1-d/100)])
    while remaining>budget and any(x[1]>0 for x in candidates):
        item=max((x for x in candidates if x[1]>0),key=lambda x:x[2])
        item[1]-=1; remaining-=item[2]; reductions.append(item[0])
    return {"original_total":round(total,2),"budget":budget,"within_budget":total<=budget,
            "revised_total":round(max(0,remaining),2),"reductions_needed":reductions,
            "revised_quantities":{x[0]:x[1] for x in candidates}}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Multi-Product Shopping Budget Constraint'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
