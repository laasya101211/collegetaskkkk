from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Campus Event Financial Planning', description='Calculate event costs, participant contributions, sponsorship shortfalls, and break-even registrations.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    costs = data.get("costs", {})
    fixed = sum(float(costs.get(k, 0)) for k in ("venue", "equipment", "transport", "certificates"))
    catering_per_person = float(data.get("catering_per_person", 0))
    registered = int(data.get("registered", 0))
    fee = float(data.get("participant_fee", 0))
    sponsorship = float(data.get("sponsorship", 0))
    total = fixed + catering_per_person * registered
    income = fee * registered + sponsorship
    contribution = max(0, total - sponsorship) / registered if registered else 0
    # Break-even registrations when each attendee contributes fee and incurs catering cost.
    margin = fee - catering_per_person
    break_even = None if margin <= 0 else max(0, __import__("math").ceil((fixed - sponsorship) / margin))
    return {"fixed_costs": round(fixed,2), "total_cost": round(total,2), "total_income": round(income,2),
            "surplus_or_shortfall": round(income-total,2), "participant_contribution_to_cover_cost": round(contribution,2),
            "break_even_registrations": break_even}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Campus Event Financial Planning'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
