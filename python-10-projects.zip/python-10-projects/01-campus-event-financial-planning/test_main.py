import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'costs': {'venue': 5000, 'equipment': 1500, 'transport': 1000, 'certificates': 500}, 'catering_per_person': 150, 'registered': 50, 'participant_fee': 300, 'sponsorship': 4000}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
