from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

app = FastAPI(title='Sports Tournament Ranking System', description='Calculate league points and tie-break values from match results and rank teams.', version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE = Path(__file__).resolve().parent

def calculate(data):
    teams={t:{"played":0,"wins":0,"draws":0,"losses":0,"points":0,"score_for":0,"score_against":0} for t in data.get("teams",[])}
    win=int(data.get("win_points",3)); draw=int(data.get("draw_points",1))
    for m in data.get("matches",[]):
        a,b=m["team_a"],m["team_b"]; sa,sb=int(m["score_a"]),int(m["score_b"])
        if a not in teams or b not in teams or a==b: raise ValueError("Match contains an unknown or duplicate team")
        A,B=teams[a],teams[b]; A["played"]+=1; B["played"]+=1; A["score_for"]+=sa; A["score_against"]+=sb; B["score_for"]+=sb; B["score_against"]+=sa
        if sa>sb: A["wins"]+=1; B["losses"]+=1; A["points"]+=win
        elif sb>sa: B["wins"]+=1; A["losses"]+=1; B["points"]+=win
        else: A["draws"]+=1; B["draws"]+=1; A["points"]+=draw; B["points"]+=draw
    ranking=[{"team":t,**v,"score_difference":v["score_for"]-v["score_against"]} for t,v in teams.items()]
    ranking.sort(key=lambda x:(-x["points"],-x["score_difference"],-x["score_for"],x["team"]))
    for i,r in enumerate(ranking,1): r["rank"]=i
    return {"rankings":ranking}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "project": 'Sports Tournament Ranking System'}

@app.post("/api/calculate")
def calculate_endpoint(data: dict):
    try:
        return calculate(data)
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
