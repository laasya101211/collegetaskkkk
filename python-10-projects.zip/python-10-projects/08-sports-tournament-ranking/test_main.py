import unittest
from main import calculate

class ProjectTests(unittest.TestCase):
    def test_sample_input(self):
        data = {'teams': ['Falcons', 'Tigers', 'Eagles'], 'matches': [{'team_a': 'Falcons', 'team_b': 'Tigers', 'score_a': 2, 'score_b': 1}, {'team_a': 'Eagles', 'team_b': 'Falcons', 'score_a': 1, 'score_b': 1}, {'team_a': 'Tigers', 'team_b': 'Eagles', 'score_a': 3, 'score_b': 0}]}
        result = calculate(data)
        self.assertIsInstance(result, dict)
        self.assertTrue(result)

if __name__ == "__main__":
    unittest.main()
